#include <stdio.h>

int main(){

    int a = 1;

    while (a < 10){
        a += 1;
    }
    printf("a: %d\n", a);

    return 0;
}